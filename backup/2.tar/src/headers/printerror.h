#ifndef PRINTERROR_H
#define PRINTERROR_H

#include "constants.h"

void printError(int code);
void affLine(char* file, int line);

#endif